import re
from collections import defaultdict

from rapidfuzz import process, fuzz

from module1_asr.automaton import AUTOMATON
from module1_asr.data.db_loader import DB_INGREDIENTS
from module1_asr.data.ingredient_synonyms import SYNONYMS


WORD_BOUNDARIES = set(" ,.()\n\t!?;:'\"")

UNIGRAM_THRESHOLD = 95
BIGRAM_THRESHOLD = 86
TRIGRAM_THRESHOLD = 82


# =========================================================
# KNOWN TERMS
# =========================================================

ALL_KNOWN_TERMS = list(set(
    [x.lower().strip() for x in DB_INGREDIENTS] +
    [x.lower().strip() for x in SYNONYMS.keys()]
))


# =========================================================
# PREFIX INDEX
# =========================================================

PREFIX_INDEX = defaultdict(list)

for term in ALL_KNOWN_TERMS:
    if term:
        PREFIX_INDEX[term[0]].append(term)


# =========================================================
# TEXT NORMALIZATION
# =========================================================

def normalize_text(text: str) -> str:
    text = text.lower()

    # remove garbage symbols
    text = re.sub(r"[^a-zA-Z0-9\s]", " ", text)

    # collapse spaces
    text = re.sub(r"\s+", " ", text)

    return text.strip()


# =========================================================
# VALID CANDIDATE FILTER
# =========================================================

def valid_candidate(token: str) -> bool:

    token = token.strip()

    if len(token) < 3:
        return False

    compact = token.replace(" ", "")

    if not compact.isalpha():
        return False

    vowel_count = sum(c in "aeiou" for c in compact)

    if vowel_count == 0:
        return False

    return True


# =========================================================
# OVERLAP RESOLUTION
# =========================================================

def resolve_overlaps(matches: list) -> list:

    matches.sort(
        key=lambda x: (
            x["span"][1] - x["span"][0],
            x.get("score", 100)
        ),
        reverse=True
    )

    accepted = []
    used = set()

    for m in matches:

        start, end = m["span"]

        positions = set(range(start, end + 1))

        if not positions & used:
            accepted.append(m)
            used |= positions

    return accepted


# =========================================================
# DEDUPLICATION
# =========================================================

def deduplicate(matches: list) -> list:

    seen = set()
    final = []

    for m in matches:

        canonical = m["canonical"]

        if canonical not in seen:
            final.append(m)
            seen.add(canonical)

    return final


# =========================================================
# TOKEN SPAN BUILDER
# =========================================================

def build_token_spans(text: str):

    tokens = text.split()

    token_spans = []

    cursor = 0

    for token in tokens:

        start_idx = text.index(token, cursor)
        end_idx = start_idx + len(token) - 1

        cursor = end_idx + 1

        token_spans.append(
            (token, start_idx, end_idx)
        )

    return token_spans


# =========================================================
# FUZZY MATCH HELPER
# =========================================================

def fuzzy_lookup(query: str, threshold: int, mode="unigram"):
    
    if not query:
        return None

    first_char = query[0]

    candidate_pool = PREFIX_INDEX.get(first_char, [])

    if not candidate_pool:
        return None

    scorer = (
        fuzz.WRatio
        if mode == "unigram"
        else fuzz.token_set_ratio
    )

    result = process.extractOne(
        query,
        candidate_pool,
        scorer=scorer,
        score_cutoff=threshold
    )

    return result


# =========================================================
# MAIN EXTRACTION
# =========================================================

def extract_ingredients(text: str) -> list:

    text_lower = normalize_text(text)

    raw_matches = []

    # =====================================================
    # LAYER 1 — EXACT MATCH (AHO CORASICK)
    # =====================================================

    for end_idx, (source, original, canonical) in AUTOMATON.iter(text_lower):

        start_idx = end_idx - len(original) + 1

        match_text = text_lower[start_idx:end_idx + 1]

        before = text_lower[start_idx - 1] if start_idx > 0 else " "
        after = text_lower[end_idx + 1] if end_idx + 1 < len(text_lower) else " "

        if before in WORD_BOUNDARIES and after in WORD_BOUNDARIES:

            raw_matches.append({
                "text": match_text,
                "canonical": canonical,
                "span": (start_idx, end_idx),
                "layer": "exact"
            })

    exact_matches = resolve_overlaps(raw_matches)

    matched_positions = set()

    for m in exact_matches:

        start, end = m["span"]

        matched_positions |= set(range(start, end + 1))

    # =====================================================
    # TOKEN SPANS
    # =====================================================

    token_spans = build_token_spans(text_lower)

    # =====================================================
    # SPAN CHECKER
    # =====================================================

    def already_matched(start, end):

        return bool(
            set(range(start, end + 1)) & matched_positions
        )

    fuzzy_matches = []

    # =====================================================
    # LAYER 2 — UNIGRAM FUZZY
    # =====================================================

    for token, start_idx, end_idx in token_spans:

        if already_matched(start_idx, end_idx):
            continue

        clean = token.strip()

        if not valid_candidate(clean):
            continue

        result = fuzzy_lookup(
            clean,
            UNIGRAM_THRESHOLD,
            mode="unigram"
        )

        if result:

            matched_term, score, _ = result

            canonical = SYNONYMS.get(
                matched_term,
                matched_term
            )

            fuzzy_matches.append({
                "text": clean,
                "canonical": canonical,
                "span": (start_idx, end_idx),
                "layer": "fuzzy_unigram",
                "score": score
            })

            matched_positions |= set(
                range(start_idx, end_idx + 1)
            )

    # =====================================================
    # LAYER 3 — BIGRAM FUZZY
    # =====================================================

    for i in range(len(token_spans) - 1):

        t1, s1, e1 = token_spans[i]
        t2, s2, e2 = token_spans[i + 1]

        if already_matched(s1, e2):
            continue

        bigram = f"{t1} {t2}"

        if not valid_candidate(bigram):
            continue

        result = fuzzy_lookup(
            bigram,
            BIGRAM_THRESHOLD,
            mode="bigram"
        )

        if result:

            matched_term, score, _ = result

            canonical = SYNONYMS.get(
                matched_term,
                matched_term
            )

            fuzzy_matches.append({
                "text": bigram,
                "canonical": canonical,
                "span": (s1, e2),
                "layer": "fuzzy_bigram",
                "score": score
            })

            matched_positions |= set(
                range(s1, e2 + 1)
            )

    # =====================================================
    # LAYER 4 — TRIGRAM FUZZY
    # =====================================================

    for i in range(len(token_spans) - 2):

        t1, s1, e1 = token_spans[i]
        t2, s2, e2 = token_spans[i + 1]
        t3, s3, e3 = token_spans[i + 2]

        if already_matched(s1, e3):
            continue

        trigram = f"{t1} {t2} {t3}"

        if not valid_candidate(trigram):
            continue

        result = fuzzy_lookup(
            trigram,
            TRIGRAM_THRESHOLD,
            mode="trigram"
        )

        if result:

            matched_term, score, _ = result

            canonical = SYNONYMS.get(
                matched_term,
                matched_term
            )

            fuzzy_matches.append({
                "text": trigram,
                "canonical": canonical,
                "span": (s1, e3),
                "layer": "fuzzy_trigram",
                "score": score
            })

            matched_positions |= set(
                range(s1, e3 + 1)
            )

    # =====================================================
    # FINAL MERGE
    # =====================================================

    all_matches = exact_matches + fuzzy_matches

    all_matches = resolve_overlaps(all_matches)

    all_matches = deduplicate(all_matches)

    return sorted(
        all_matches,
        key=lambda x: x["span"][0]
    )